-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: sql.ares-system.nazwa.pl:3305
-- Czas wygenerowania: 17 Cze 2009, 19:52
-- Wersja serwera: 5.0.75
-- Wersja PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Baza danych: `ares-system_7`
-- 

-- --------------------------------------------------------

-- 
-- Struktura tabeli dla  `pensja`
-- 

CREATE TABLE `pensja` (
  `pen_id` int(11) NOT NULL auto_increment,
  `pen_prc_id` int(11) default NULL,
  `pen_kwota` float default NULL,
  PRIMARY KEY  (`pen_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=5 ;

-- 
-- Zrzut danych tabeli `pensja`
-- 

INSERT INTO `pensja` VALUES (1, 1, 125630);
INSERT INTO `pensja` VALUES (2, 2, 125631);
INSERT INTO `pensja` VALUES (3, 3, 125629);
INSERT INTO `pensja` VALUES (4, 4, 125629);

-- --------------------------------------------------------

-- 
-- Struktura tabeli dla  `pracownicy`
-- 

CREATE TABLE `pracownicy` (
  `prc_id` int(11) NOT NULL auto_increment,
  `prc_imie` varchar(100) default NULL,
  `prc_nazwisko` varchar(100) default NULL,
  `prc_pen_id` int(11) default NULL,
  PRIMARY KEY  (`prc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=5 ;

-- 
-- Zrzut danych tabeli `pracownicy`
-- 

INSERT INTO `pracownicy` VALUES (1, 'Marcin', 'Armata', 1);
INSERT INTO `pracownicy` VALUES (2, 'Marcin', 'Bielak', 2);
INSERT INTO `pracownicy` VALUES (3, 'Jakub', 'Mytnik', 3);
INSERT INTO `pracownicy` VALUES (4, 'Radosław', 'Scheibinger', 4);
